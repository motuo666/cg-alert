#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
echo "Applying cg-alert fixpack..."
# Copy scripts
rsync -av "$ROOT/scripts/" ./scripts/
# Add slack lib dir if needed
mkdir -p ./scripts/lib
rsync -av "$ROOT/scripts/lib/" ./scripts/lib/ 2>/dev/null || true
# Add package patch and merge with jq if available
if command -v jq >/dev/null 2>&1; then
  echo "Patching package.json (adding minimist)..."
  jq -s '.[0] * .[1]' package.json "$ROOT/package.patch.json" > package.json.tmp && mv package.json.tmp package.json
else
  echo "NOTE: Install jq and run: jq -s '.[0] * .[1]' package.json \"$ROOT/package.patch.json\" > package.json.tmp && mv package.json.tmp package.json"
fi
# Repair index.html CSP
node "$ROOT/scripts/repair_index_csp.js" || true
echo "Done. Next: npm ci"